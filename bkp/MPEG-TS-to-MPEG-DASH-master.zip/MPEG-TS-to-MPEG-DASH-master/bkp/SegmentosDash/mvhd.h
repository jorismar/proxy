//
//  mvhd.h
//  
//
//  Created by Josue on 30/09/15.
//
//

#ifndef ____mvhd__
#define ____mvhd__

#include <stdio.h>
class Mvhd{

public:
    int creation_time;
    int modification_time;
    int timescale;
    int duration;
    int rate;
};
#endif /* defined(____mvhd__) */
