//
//  escreveFile.cpp
//  
//
//  Created by Josue on 24/09/15.
//
//

#include "escreveFile.h"

EscreveFile::EscreveFile(){
    
}

void EscreveFile::escrevefile(){

}
void lerarquivo(){
    
}
void getSegmentos(Segmentos seg){
    this->fila = cria();
    for(int i = 0; i<10;i++){
        insere_fila(this->fila,seg);
    }
    
}