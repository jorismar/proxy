#include <string>
#include <string.h>
using std::string;

class Ftype{
	public:
		int version;
		string major_brand;
		string menor_brand;
		string compatible_brand[2];
};