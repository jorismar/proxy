#include "boxftyp.h"

Boxftyp::Boxftyp(){}

˜Boxftyp::Boxftyp(){}